## JavaScript ES6 / ES2015 YouTube Series

This is the source code for each video in the YouTube Series

01 - Babel Setup
02 - let & const
03 - Classes
04 - Template Strings
05 - String & Number Functions
06 - Default Params & Spread Operator
07 - Set & Map
08 - Arrow Functions
09 - Promises
10 - Generators
