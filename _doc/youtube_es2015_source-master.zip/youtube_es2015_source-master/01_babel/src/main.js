class User{
  register(){
    console.log('User Registered...');
  }
}
